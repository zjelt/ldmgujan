from pi_pico_lcd_rgb_grove import *
from machine import Pin, I2C
from time import sleep_ms

# Crée un objet I2C
i2c0 = I2C(0, scl=Pin(9), sda=Pin(8), freq=400000)    # I2C0 utilisé  

# Crée un objet Lcd_rgb_grove
lcd = Lcd_rgb_grove(i2c0)

lcd.color(0, 0, 0)

while True:
    # Affichage
    lcd.clear()
    lcd.setCursor(2, 0)
    lcd.write('hello World')

    # Couleur
    lcd.color(255, 0, 0)
    sleep_ms(500)
    lcd.color(0, 255, 0)
    sleep_ms(500)
    lcd.color(0, 0, 255)
    sleep_ms(500)
