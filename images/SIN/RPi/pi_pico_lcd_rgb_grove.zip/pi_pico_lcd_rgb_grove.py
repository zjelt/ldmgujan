# (c) 2022 Christophe Gueneau
from time import sleep_ms, sleep_us

class Lcd_rgb_grove():
    
    def __init__(self, i2c):
        self._i2c = i2c
        self.set_register(0x00, 0)
        self.set_register(0x01, 0)
        
        # Toutes les Leds controllées par PWM
        self.set_register(0x08, 0xAA)

        # Attente initialisation après mise sous tension
        sleep_ms(50)

        # Envoi configuration afficheur 2 lignes
        self.cmd(0x20 | 0x04 | 0x08)
        sleep_us(4500)
        self.cmd(0x20 | 0x04 | 0x08)
        sleep_us(150)
        self.cmd(0x20 | 0x04 | 0x08)
        self.cmd(0x20 | 0x04 | 0x08)

        # Allumage afficheur
        self.disp_ctrl = 0x04 | 0x00 | 0x00
        self.display1(True)
        self.clear()
        self.disp_mode = 0x02 | 0x00
        self.cmd(0x04 | self.disp_mode)

    def set_register(self, reg, val):
        val = bytes((reg, val))
        self._i2c.writeto(0x62, val)

    def color(self, r, g, b):
        self.set_register(0x04, r)
        self.set_register(0x03, g)
        self.set_register(0x02, b)

    def cmd(self, command):
        assert command >= 0 and command < 256
        val = bytes((0x80, command))
        self._i2c.writeto(0x3e, val)

    def write_char(self, c):
        assert c >= 0 and c < 256
        val = bytes((0x40, c))
        self._i2c.writeto(0x3e, val)

    def write(self, text):
        text = str(text)
        for char in text:
            self.write_char(ord(char))

    def setCursor(self, col, row):
        col = (col | 0x80) if row == 0 else (col | 0xc0)
        self.cmd(col)

    def display1(self, state):
        if state:
            self.disp_ctrl |= 0x04
            self.cmd(0x08  | self.disp_ctrl)
        else:
            self.disp_ctrl &= ~0x04
            self.cmd(0x08  | self.disp_ctrl)

    def clear(self):
        self.cmd(0x01)
        sleep_ms(2)

if __name__ == '__main__':

    from machine import Pin, I2C
    from time import sleep_ms

    # Crée un objet I2C
    i2c0 = I2C(0, scl=Pin(9), sda=Pin(8), freq=400000)    # I2C0 utilisé  

    # Crée un objet Lcd_rgb_grove
    lcd = Lcd_rgb_grove(i2c0)
    lcd.color(0, 0, 0)

    while True:
        # Affichage
        lcd.clear()
        lcd.setCursor(2, 0)
        lcd.write('hello World')

        # Couleur
        lcd.color(255, 0, 0)
        sleep_ms(500)
        lcd.color(0, 255, 0)
        sleep_ms(500)
        lcd.color(0, 0, 255)
        sleep_ms(500)


